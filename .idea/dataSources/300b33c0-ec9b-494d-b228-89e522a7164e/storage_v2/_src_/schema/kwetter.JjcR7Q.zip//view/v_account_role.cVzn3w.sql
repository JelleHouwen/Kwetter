create definer = root@localhost view v_account_role as
select `kwetter`.`user_role`.`User_ID`  AS `user_id`,
       `kwetter`.`user_role`.`roles_ID` AS `roles_id`,
       `kwetter`.`user`.`USERNAME`      AS `username`,
       `kwetter`.`user`.`PASSWORD`      AS `password`,
       `kwetter`.`role`.`ROLENAME`      AS `rolename`
from ((`kwetter`.`user_role` join `kwetter`.`user` on ((`kwetter`.`user_role`.`User_ID` = `kwetter`.`user`.`ID`)))
       join `kwetter`.`role` on ((`kwetter`.`user_role`.`roles_ID` = `kwetter`.`role`.`ID`)));

